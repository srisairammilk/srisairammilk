const KEY='sri_sairam_orders';
function getOrders(){return JSON.parse(localStorage.getItem(KEY)||'[]')}
function saveOrders(a){localStorage.setItem(KEY,JSON.stringify(a))}
function addOrder(){
 const shop=document.getElementById('shop').value.trim();
 const milk=document.getElementById('milk').value;
 const qty=Number(document.getElementById('qty').value);
 const driver=document.getElementById('driver').value;
 if(!shop||!qty||qty<1){alert('கடை பெயர் மற்றும் பாக்கெட் எண்ணிக்கை உள்ளிடவும்');return}
 const a=getOrders();
 a.push({shop,milk,qty,driver,time:new Date().toLocaleTimeString('ta-IN',{hour:'2-digit',minute:'2-digit'})});
 saveOrders(a); document.getElementById('shop').value=''; render();
}
function clearOrders(){if(confirm('இன்றைய பதிவுகளை அழிக்கவா?')){saveOrders([]);render()}}
function render(){
 const a=getOrders();
 document.getElementById('todayQty').textContent=a.reduce((s,x)=>s+x.qty,0);
 document.getElementById('pending').textContent=a.length;
 document.getElementById('orders').innerHTML=a.length?a.map((x,i)=>`<div class="order"><strong>${i+1}. ${x.shop}</strong><br>${x.milk} × ${x.qty} | ${x.driver}<br><small>${x.time}</small></div>`).join(''):'<p>இன்று எந்த பதிவும் இல்லை.</p>';
}
render();
